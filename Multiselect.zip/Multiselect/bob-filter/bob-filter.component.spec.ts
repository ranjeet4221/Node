import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { BobFilterComponent } from './bob-filter.component';

describe('BobFilterComponent', () => {
  let component: BobFilterComponent;
  let fixture: ComponentFixture<BobFilterComponent>;

  beforeEach(async(() => {
	TestBed.configureTestingModule({
		declarations: [ BobFilterComponent ]
	})
	.compileComponents();
  }));

  beforeEach(() => {
	fixture = TestBed.createComponent(BobFilterComponent);
	component = fixture.componentInstance;
	fixture.detectChanges();
  });

  it('should be created', () => {
	expect(component).toBeTruthy();
  });
});
