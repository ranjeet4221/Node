//////////////////////////////////////////
// Copyright (c) 2018 EXL Services
//////////////////////////////////////////

/* angular modules */
import { Component, OnInit } from '@angular/core';
import { Observable } from 'rxjs/Observable';
import { Observer } from 'rxjs/Observer';
import { Store } from '@ngrx/store';

/* primeng service*/
import { ConfirmationService, SelectItem } from 'primeng/primeng';

/* models */
import { ListItem } from '@core/components/multiselect-dropdown/multiselect.model';
import { BobFilter, LineofBusiness, BOBState, PolicyFilter, BOBFilterCriteriaJson } from '@bob/models';


/* actions */
import * as bobFilterAction from '../../actions/bob-filter.action';
import * as policyAction from '../../actions/policy.action';

/* reducers */
import * as fromRootReducer from '@app/reducers';
import * as fromBobFilterReducer from '../../reducers/index';
import * as fromAuthReducer from '@auth/reducers';

/* shared utility */
import { SharedUtility } from '@shared/utilities/shared-util';

import { BaseBOBFilterComponent } from './base.bob-filter.component';

@Component({
	selector: 'app-bob-filter',
	templateUrl: './bob-filter.component.html',
	styleUrls: ['./bob-filter.component.scss']
})
export class BobFilterComponent extends BaseBOBFilterComponent implements OnInit {

	private _username: string;
	private _viewAs: string;

	public bobFilter$: Observable<BobFilter[]>;
	public expanded$: Observable<boolean>;

	public filterCriteria: BOBFilterCriteriaJson = {
		baseSearch: [],
		baseSearchValue: '',
		baseSearchParam: 2,
		expirationDate: 0,
		expirationDateRangeStart: null,
		expirationDateRangeEnd: null,
		lastAuditDate: 0,
		lastAuditDateRangeStart: null,
		lastAuditDateRangeEnd: null,
		states: [],
		lineOfBusinesses: [],
		serviceCodes: [],
		excludeWithActiveWO: false,
		excludeCancelled: false,
		filterForView: 1
	};

	public activeFilterId: number;
	public showAddFilterDialog: boolean;
	public showUpdateFilterDialog = false;
	public hideUpdateFilterDialog = true;
	public systemUserId: number;

	public serviceCodeDropdownSettings = {};
	public selectedServiceCodeItems = [];
	public serviceCodeList: ListItem[];

	public stateDropdownSettings = {};
	public selectedStateItems = [];
	public stateList: ListItem[];
	public bobFilters: BobFilter[];
    public lineOfBusinessDropdownSettings;
    public lineOfBusinessList: ListItem[];

	constructor(public _store: Store<fromRootReducer.State>, public confirmationService: ConfirmationService) {
		super(_store);

		this.bobFilter$ = this._store.select(fromBobFilterReducer.selectAllBobFilter)
			.filter(f => !!f);

		this.expanded$ = this._store.select(fromBobFilterReducer.getExpanded);
	}

	ngOnInit() {
		this.MultiSelelectConfig();
		this.LookupData();

		this._store.select(fromBobFilterReducer.getActiveFilterCriteria)
			.filter(f => !!f)
			.subscribe(f => {
				this.filterCriteria = { ...f };
			});

		this._store.select(fromBobFilterReducer.getActiveFilterId)
			.subscribe(id => {
				this.activeFilterId = id;
			});
	}


	
	public getSelectedLineOfBusinessItems(): string {
		let lobItemsMsg = this.filterCriteria.lineOfBusinesses.map(x => x.itemName).join('; ')
					|| 'All Lines of Business';
		return lobItemsMsg;
	}

	public getSelectedStateItems(): string {
		let stateItemsMsg = this.filterCriteria.states.map(x => x.itemName).join('; ')
			|| 'All States';
		return stateItemsMsg;
	}

	public getExcludeCancelled(): string {
		return this.filterCriteria.excludeCancelled ? 'Excluded' : 'Included';
	}

	public getExcludeWithActiveWO(): string {
		return this.filterCriteria.excludeWithActiveWO ? 'Excluded' : 'Included';
	}

	public getExpirationDate(): string {
		let expDate = '';
		switch (this.filterCriteria.expirationDate) {
			case 30:
				expDate = '30 Days';
				break;
			case 60:
				expDate = '60 Days';
				break;
			case 90:
				expDate = '90 Days';
				break;
			case -1:
				expDate = this.readableDate(this.filterCriteria.expirationDateRangeStart) + ' - ' + this.readableDate(this.filterCriteria.expirationDateRangeEnd);
				break;
			default:
				expDate = 'Not Selected';
		}
		return expDate;
	}

	public getLastAuditDate(): string {
		let laDate = '';
		switch (this.filterCriteria.lastAuditDate) {
			case 30:
				laDate = '30 Days';
				break;
			case 60:
				laDate = '60 Days';
				break;
			case 90:
				laDate = '90 Days';
				break;
			case -1:
				laDate = this.readableDate(this.filterCriteria.lastAuditDateRangeStart) + ' - ' + this.readableDate(this.filterCriteria.lastAuditDateRangeEnd);
				break;
			default:
				laDate = 'Not Selected';
		}
		return laDate;
	}

	public readableDate(d: Date): string {
		if (d===null) return 'Not Selected'
		else return d.getMonth()+1 + '/' + d.getDate() + '/' + d.getFullYear();
	}

	public onDeleteFilter(): void {
		this.confirmationService.confirm({
			message: 'Are you sure that you want to delete?',
			header: 'Confirmation',
			icon: 'fa fa-question-circle',
			accept: () => {
				this._store
					.dispatch(new bobFilterAction.DeleteBobFilterAction({
						username: this._username,
						viewAs: 'manager',
						filterId: this.activeFilterId
					}));
			}
		});
	}

	public onSaveAs(): void {
		this.showAddFilterDialog = true;
	}

	public onUpdateFilter(): void {
		const bobFilter = this.bobFilters.find(f => f.bookSearchFilterId === +this.activeFilterId);
		this.showUpdateFilterDialog = true;
		const filter: BobFilter = {
			bookSearchFilterId: this.activeFilterId,
			filterCriteria: JSON.stringify(this.filterCriteria),
			filterName: bobFilter.filterName,
			isDefault: false,
			systemUserId: bobFilter.systemUserId
		}

		this._store
			.dispatch(new bobFilterAction.UpdateBobFilterAction({
				username: this._username,
				viewAs: 'manager',
				bobfilter: filter
			}));
	}

	public onCloseUpdateDialog(): void {
		this.showUpdateFilterDialog = false;
	}

	public onChangeLastAuditDate(dataValue: number): void {
		let lastAuditDate = this.GetDays(Number(dataValue));
		let lastAuditDateStart = lastAuditDate < 1 ? null : new Date();
		let lastAuditDateEnd = lastAuditDate < 1 ? null : this.GetNextDate(lastAuditDate);

		this.updateActiveFilterCriteria('lastAuditDate', lastAuditDate)
		this.updateActiveFilterCriteria('lastAuditDateRangeStart', lastAuditDateStart);
		this.updateActiveFilterCriteria('lastAuditDateRangeEnd', lastAuditDateEnd);
	}

	public onChangeExpirationDate(dataValue: string): void {
		let expirationDate = this.GetDays(Number(dataValue));
		let expirationDateStart = expirationDate < 1 ? null : new Date();
		let expirationDateEnd = expirationDate < 1 ? null : this.GetNextDate(expirationDate);

		this.updateActiveFilterCriteria('expirationDate', expirationDate)
		this.updateActiveFilterCriteria('expirationDateRangeStart', expirationDateStart);
		this.updateActiveFilterCriteria('expirationDateRangeEnd', expirationDateEnd);
	}

	public onApplyFilter(): void {
		let bobFilter = {
			bookSearchFilterId: this.activeFilterId,
			filterCriteria: JSON.stringify(this.filterCriteria),
			filterName: '',
			isDefault: false,
			systemUserId: 0
		};
		this._store.dispatch(new policyAction.SetGridPageAction(1));
		this._store.dispatch(new bobFilterAction.SetSelecedBOBFilter(bobFilter));

	}

	public onItemSelect(field: string, item: ListItem): void {
		let currentList = this.filterCriteria[field];
		this.updateActiveFilterCriteria(field, [...currentList, item]);

	}

	public onItemDeSelect(field: string, item: ListItem): void {
		let currentList = this.filterCriteria[field] as ListItem[];
		this.updateActiveFilterCriteria(field, currentList.filter(f => f.id !== item.id));
	}

	public onSelectAll(field: string, items: ListItem[]): void {
		this.updateActiveFilterCriteria(field, items);
	}

	public onDeSelectAll(field: string, items: ListItem[]): void {
		this.updateActiveFilterCriteria(field, []);
	}

	public LookupData(): void {
		this._store.select(fromBobFilterReducer.selectAllLineofBusiness).filter(f => !!f)
			.takeUntil(this.unsubscribe)
			.subscribe(t => {
				this.lineOfBusinessList = t.map(b => ({ id: b.id, itemName: b.name }));
			});

		this._store.select(fromBobFilterReducer.selectAllState).filter(f => !!f)
			.takeUntil(this.unsubscribe)
			.subscribe(t => {
				this.stateList = t.map(b => ({ id: b.code, itemName: b.name }));
			});

		this.bobFilter$
			.filter(u => !!u)
			.subscribe(v => {
				this.bobFilters = v;
			})

		this._store.select(fromAuthReducer.getUser)
			.filter(u => !!u)
			.takeUntil(this.unsubscribe)
			.subscribe(u => {
				this._username = SharedUtility.GetUserNameWithoutDomain(u.selectedUser);
				this._viewAs = 'manager'; // u.viewAs;
			});
	}

	public onClose(event: any): void {
		this.showAddFilterDialog = false;
	}

	public MultiSelelectConfig(): void {
		this.lineOfBusinessDropdownSettings = {
			singleSelection: false,
			text: 'Select Line of Business',
			selectAllText: 'Select All',
			unSelectAllText: 'UnSelect All',
			enableSearchFilter: false,
			classes: 'myclass custom-class'
		};

		this.serviceCodeDropdownSettings = {
			singleSelection: false,
			text: 'Select Service Code',
			selectAllText: 'Select All',
			unSelectAllText: 'UnSelect All',
			enableSearchFilter: false,
			classes: 'myclass custom-class'
		};

		this.stateDropdownSettings = {
			singleSelection: false,
			text: 'Select State',
			selectAllText: 'Select All',
			unSelectAllText: 'UnSelect All',
			enableSearchFilter: false,
			classes: 'myclass custom-class'
		};
	}

	private GetNextDate(previousDateCount: number): Date {
		const today = new Date();
		const priorDate = new Date();
		priorDate.setDate(priorDate.getDate() + previousDateCount);
		return priorDate;
	}

	private GetDays(value: number): number {
		let days = 0;
		switch (value) {
			case 0:
				days = 0;
				break;
			case 1:
				days = 30;
				break;
			case 2:
				days = 60;
				break;
			case 3:
				days = 90;
				break;
			case 4:
				days = -1;
				break;
		}
		return days;
	}

	togglePolicyWithActive() {
		let excludeWithActiveWO = !this.filterCriteria.excludeWithActiveWO;
		this.updateActiveFilterCriteria('excludeWithActiveWO', excludeWithActiveWO);
	}

	toggleCancelledPolicy() {
		let excludeCancelled = !this.filterCriteria.excludeCancelled;
		this.updateActiveFilterCriteria('excludeCancelled', excludeCancelled);
	}

	updateActiveFilterCriteria(fieldName, value) {
		this.filterCriteria[fieldName] = value;
		this._store.dispatch(new bobFilterAction.UpdateActiveBobFilterAction(this.filterCriteria));
	}

	loadFilter(id: number) {
		this._store.dispatch(new bobFilterAction.LoadFilterAction(id));
	}

	toggleExpandCollapse() {
		this._store.dispatch(new bobFilterAction.ToggleExpandCollapseAction());
	}
}
