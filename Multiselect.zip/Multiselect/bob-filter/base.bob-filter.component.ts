//////////////////////////////////////////
//	Copyright (c) 2018 EXL Services
//////////////////////////////////////////

/* core modules */
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs/Observable';
import { Store } from '@ngrx/store';

/* actions */
import * as bobFilterAction from '../../actions/bob-filter.action';

/* reducer */
import * as fromAuthReducer from '@auth/reducers';
import * as fromRootReducer from '@app/reducers';

/* shared utility */
import { SharedUtility } from '@shared/utilities/shared-util';
import { SubscriptionComponent } from '@shared/components/subscriptionComponent';
import { User } from '@auth/models';

@Injectable()
export class BaseBOBFilterComponent extends SubscriptionComponent {

	public constructor(public _store: Store<fromRootReducer.State>) {
		super();

		this._store.select(fromAuthReducer.getUser)
			.filter(u => !!u)
			.distinctUntilChanged((x: User, y: User) => {
				return x.selectedUser === y.selectedUser;
			})
			.takeUntil(this.unsubscribe)
			.subscribe(u => {
				this._store.dispatch(new bobFilterAction.GetBobFilterAction({ username: SharedUtility.GetUserNameWithoutDomain(u.selectedUser), viewAs: 'manager' }));
			});
	}
}
